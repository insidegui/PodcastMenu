var progressbar = document.querySelector('#progressbar');

if (progressbar && typeof(progressbar) != 'undefined') {
    location.hash = "#progressbar";
    document.querySelector('#progressbar').style.paddingTop = '10px';
}